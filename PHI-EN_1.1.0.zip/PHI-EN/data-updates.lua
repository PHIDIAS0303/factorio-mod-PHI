-- accumulator
data.raw["accumulator"]["accumulator"].fast_replaceable_group = "accumulator"
data.raw["accumulator"]["accumulator-mk2"].fast_replaceable_group = data.raw["accumulator"]["accumulator"].fast_replaceable_group
data.raw["accumulator"]["accumulator-mk3"].fast_replaceable_group = data.raw["accumulator"]["accumulator"].fast_replaceable_group
data.raw["accumulator"]["accumulator-mk4"].fast_replaceable_group = data.raw["accumulator"]["accumulator"].fast_replaceable_group
data.raw["accumulator"]["accumulator-mk5"].fast_replaceable_group = data.raw["accumulator"]["accumulator"].fast_replaceable_group
data.raw["accumulator"]["accumulator-mk6"].fast_replaceable_group = data.raw["accumulator"]["accumulator"].fast_replaceable_group
data.raw["accumulator"]["accumulator-mk7"].fast_replaceable_group = data.raw["accumulator"]["accumulator"].fast_replaceable_group
data.raw["accumulator"]["accumulator-mk8"].fast_replaceable_group = data.raw["accumulator"]["accumulator"].fast_replaceable_group

-- solar-panel
data.raw["solar-panel"]["solar-panel"].fast_replaceable_group = "solar-panel"
data.raw["solar-panel"]["solar-panel-mk2"].fast_replaceable_group = data.raw["solar-panel"]["solar-panel"].fast_replaceable_group
data.raw["solar-panel"]["solar-panel-mk3"].fast_replaceable_group = data.raw["solar-panel"]["solar-panel"].fast_replaceable_group
data.raw["solar-panel"]["solar-panel-mk4"].fast_replaceable_group = data.raw["solar-panel"]["solar-panel"].fast_replaceable_group
data.raw["solar-panel"]["solar-panel-mk5"].fast_replaceable_group = data.raw["solar-panel"]["solar-panel"].fast_replaceable_group
data.raw["solar-panel"]["solar-panel-mk6"].fast_replaceable_group = data.raw["solar-panel"]["solar-panel"].fast_replaceable_group
data.raw["solar-panel"]["solar-panel-mk7"].fast_replaceable_group = data.raw["solar-panel"]["solar-panel"].fast_replaceable_group
data.raw["solar-panel"]["solar-panel-mk8"].fast_replaceable_group = data.raw["solar-panel"]["solar-panel"].fast_replaceable_group
