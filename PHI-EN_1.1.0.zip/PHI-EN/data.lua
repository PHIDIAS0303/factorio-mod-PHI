require("prototypes")
require("technology-compound-power")